#ifndef _TEST_H
#define _TEST_H


void LVGL_test(void);
double fmap(double x, double in_min, double in_max, double out_min, double out_max);

#endif

