#include "test.h"
#include "../lvgl/lvgl.h"
#include "stdio.h"
#include "cmsis_os.h"
#include "main.h"

#include "sys_adc.h"

extern osMutexId SYSMutexHandle;


static void lv_test_cell(lv_task_t * task);
static void lv_test_cell_interface(void);


void LVGL_test(void)
{
	xSemaphoreTake(SYSMutexHandle,osWaitForever);
	lv_test_cell_interface();
	xSemaphoreGive(SYSMutexHandle);
}


  

#if 1

static lv_obj_t * labelBatt;
float Vbattery_Value = 0.0;

static void lv_test_cell(lv_task_t * task)
{ 
	
	Vbattery_Value = get_batt();
//  Vbattery_Value = 4.1;
//	
	const char * battSymbol[] =
	{
		LV_SYMBOL_BATTERY_EMPTY,
		LV_SYMBOL_BATTERY_1,
		LV_SYMBOL_BATTERY_2,
		LV_SYMBOL_BATTERY_3,
		LV_SYMBOL_BATTERY_FULL
	};
	
 int symIndex = fmap(Vbattery_Value,3.2f, 4.2f,0, __Sizeof(battSymbol));
 lv_label_set_text(labelBatt, battSymbol[symIndex]);

}          

static void lv_test_cell_interface(void)
{
//	xSemaphoreTake(SYSMutexHandle,osWaitForever);
	
	lv_task_t * taskTopBarUpdate;
	
  labelBatt = lv_label_create(lv_scr_act(),NULL);
	lv_label_set_text(labelBatt," ");
	lv_obj_align(labelBatt, NULL, LV_ALIGN_CENTER, 0 , 0);
	
	taskTopBarUpdate = lv_task_create(lv_test_cell, 1000, LV_TASK_PRIO_LOW, NULL);
	lv_test_cell(taskTopBarUpdate);
	
//	xSemaphoreGive(SYSMutexHandle);
}


double fmap(double x, double in_min, double in_max, double out_min, double out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
#endif


