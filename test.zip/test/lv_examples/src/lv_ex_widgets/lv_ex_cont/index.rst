C
^

Container with auto-fit
"""""""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_cont/lv_ex_cont_1.*
  :alt: Container example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_cont/lv_ex_cont_1.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
